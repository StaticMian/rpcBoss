package io.protostuff;

/**
 * Dummy file to please the ishy sonatype repository (javadoc friggin required).
 */
public class Uber
{
    private Uber()
    {
    }
}
