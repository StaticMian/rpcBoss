//========================================================================
//Copyright 2007-2010 David Yu dyuproject@gmail.com
//------------------------------------------------------------------------
//Licensed under the Apache License, Version 2.0 (the "License");
//you may not use this file except in compliance with the License.
//You may obtain a copy of the License at 
//http://www.apache.org/licenses/LICENSE-2.0
//Unless required by applicable law or agreed to in writing, software
//distributed under the License is distributed on an "AS IS" BASIS,
//WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//See the License for the specific language governing permissions and
//limitations under the License.
//========================================================================

package io.protostuff.runtime;

import io.protostuff.ProtostuffPipeTest;
import io.protostuff.runtime.CollectionTest.Employee;
import io.protostuff.runtime.CollectionTest.Task;
import io.protostuff.runtime.MathObjectsTest.Payment;

/**
 * Test case for pipes generated at runtime.
 * 
 * @author David Yu
 * @created Oct 9, 2010
 */
public class RuntimePipeTest extends ProtostuffPipeTest
{

    static <T> RuntimeSchema<T> getSchema(Class<T> typeClass)
    {
        return (RuntimeSchema<T>) RuntimeSchema.getSchema(typeClass);
    }

    @Override
    public void testFoo() throws Exception
    {
        RuntimeSchema<Foo> schema = getSchema(Foo.class);

        Foo foo = SerializableObjects.foo;

        roundTrip(foo, schema, schema.getPipeSchema());
    }

    @Override
    public void testBar() throws Exception
    {
        RuntimeSchema<Bar> schema = getSchema(Bar.class);

        Bar bar = SerializableObjects.bar;

        roundTrip(bar, schema, schema.getPipeSchema());
    }

    @Override
    public void testBaz() throws Exception
    {
        RuntimeSchema<Baz> schema = getSchema(Baz.class);

        Baz baz = SerializableObjects.baz;

        roundTrip(baz, schema, schema.getPipeSchema());
    }

    public void testEmployee() throws Exception
    {
        RuntimeSchema<Employee> schema = getSchema(Employee.class);

        Employee emp = CollectionTest.filledEmployee();

        roundTrip(emp, schema, schema.getPipeSchema());
    }

    public void testTask() throws Exception
    {
        RuntimeSchema<Task> schema = getSchema(Task.class);

        Task task = CollectionTest.filledTask();

        roundTrip(task, schema, schema.getPipeSchema());
    }

    public void testPayment() throws Exception
    {
        RuntimeSchema<Payment> schema = getSchema(Payment.class);

        Payment payment = MathObjectsTest.filledPayment();

        roundTrip(payment, schema, schema.getPipeSchema());
    }

    public void testPojoWithArrayAndSet() throws Exception
    {
        RuntimeSchema<PojoWithArrayAndSet> schema = getSchema(PojoWithArrayAndSet.class);

        PojoWithArrayAndSet p = SerDeserTest.filledPojoWithArrayAndSet();

        roundTrip(p, schema, schema.getPipeSchema());
    }

}
